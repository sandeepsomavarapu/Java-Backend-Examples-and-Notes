package coreJavaCaseStudy;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class BankClient {

	public static void main(String[] args) {
		HashMap<Long, Account> accounts = new HashMap<Long, Account>();
		HashMap<Long, Transactions> transactions = new HashMap<Long, Transactions>();
		long accNo;
		String accHolderName;
		String typeofAcc;
		float accBal = 1;
		String address = null;
		long contactno;
		boolean value = true;
		Scanner scan = new Scanner(System.in);
		while (value) {
			System.out.println("****************BANK APPLICATION*********************");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.FundTransfer");
			System.out.println("6.Print Bank Statement");
			System.out.println("7.Exit");
			Account account;// declared
			int option = scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("YOU HAVE OPTED TO CREATE AN ACCOUNT");
				System.out.print("Enter your name:-");
				accHolderName = scan.next();
				System.out.print("Enter the type of your account:-");
				typeofAcc = scan.next();
				System.out.print("Enter your contact number:-");
				contactno = scan.nextLong();
				System.out.print("Enter your address:-");
				address = scan.next();
				accNo = contactno - 100000000;
				System.out.println("Your account number is:-" + accNo);
				account = new Account(accNo, accHolderName, typeofAcc, accBal, address, contactno);
				accounts.put(accNo, account);
				System.out.println("Account is create Successfully,with your account number as:-" + accNo);
				break;
			case 2:
				System.out.println("*****SHOW BALANCE*****");
				System.out.print("Enter your account number:-");
				accNo = scan.nextLong();
				account = accounts.get(accNo);
				System.out.println("Your account balance is:-" + account.getAccBal());
				break;
			case 3:
				System.out.println("*****DEPOSIT******");
				System.out.print("Enter your account number:-");
				accNo = scan.nextLong();
				System.out.print("Enter your amount to deposit:-");
				float depositAmount = scan.nextFloat();
				account = accounts.get(accNo);
				float existingAmount = account.getAccBal();
				float finalAmount = depositAmount + existingAmount;
				account.setAccBal(finalAmount);
				accounts.put(accNo, account);
				Date dateOfTrans = new Date();
				Transactions transaction = new Transactions(100, accNo, 0, depositAmount, dateOfTrans, "deposit",
						finalAmount);
				transactions.put(transaction.getTransId(), transaction);
				System.out.println("Your Current Balance after deposit is:-" + finalAmount);
				break;
			case 4:
				 System.out.println("*****WITHDRAW******"); // ctrl+shift+/  ctrl+shift+\
				System.out.print("Enter your account number:-");
				accNo = scan.nextLong();
				System.out.print("Enter your amount:-");
				float withdrawAmount = scan.nextFloat();
				account = accounts.get(accNo);
				float balance = account.getAccBal();
				float finalAmount1 = balance - withdrawAmount;
				account.setAccBal(finalAmount1);
				accounts.put(accNo, account);
				Date dateOfTrans1 = new Date();
				Transactions transaction1 = new Transactions(111, accNo, 0, withdrawAmount, dateOfTrans1, "withdraw",
						finalAmount1);
				transactions.put(transaction1.getTransId(), transaction1);
				System.out.println();
				System.out.println("your current balance after withdrawl is:-" + finalAmount1);
				break;
			case 5:
				System.out.println("******FUND TRANSFER*****");
				System.out.print("Enter your from account number:-");
				long accNoFrom = scan.nextLong();
				System.out.print("Enter your to account number:-");
				long accNoTo = scan.nextLong();
				System.out.print("Enter your amount to transfer:-");
				float transferAmount = scan.nextFloat();// getting the amount to transfer

				Account fromAccount = accounts.get(accNoFrom);

				Account toAccount = accounts.get(accNoTo);

				float fromAccountBalance = fromAccount.getAccBal();

				float ToAccountBalance = toAccount.getAccBal();

				fromAccountBalance = fromAccountBalance - transferAmount;

				ToAccountBalance = ToAccountBalance + transferAmount;

				fromAccount.setAccBal(fromAccountBalance);

				toAccount.setAccBal(ToAccountBalance);

				accounts.put(accNoFrom, fromAccount);

				accounts.put(accNoTo, toAccount);

				float currentbal = fromAccount.getAccBal();

				Date dateOfTransfer = new Date();

				Transactions transaction2 = new Transactions(222, accNoFrom, accNoTo, transferAmount, dateOfTransfer,
						"fund transfer", currentbal);

				transactions.put(transaction2.getTransId(), transaction2);

				System.out.println("YOUR CURRENT ACCOUNT BALANCE AFTER FUND TRANSFER IS:-" + fromAccount.getAccBal());

				break;

			case 6:
				Transactions trans = null;
				Set<Long> set = transactions.keySet();
				Iterator<Long> keys = set.iterator();
				while (keys.hasNext()) {
					Long key = keys.next();
					trans = transactions.get(key);
					System.out.printf("%-15s%-15s%-15s%-15s%-15s%-15s%-15s ", "transId",

							"accNoFrom", "accNoTo", "ammount", "dateOfTrans", "transType", "Balance");
					System.out.println();
					System.out.println(trans.getTransId() + " " + trans.getAccNoFrom() + " " + trans.getAccNoTo() + " "
							+ trans.getAmmout() + " " + trans.getDateOfTrans() + " " + trans.getTranstype() + " "
							+ trans.getBalance());

				}
				break;
			default:

				System.out.println("****Thank you for choosing our bank****");

				value = false;

				System.exit(0);

				break;

			}

		}

	}

}
