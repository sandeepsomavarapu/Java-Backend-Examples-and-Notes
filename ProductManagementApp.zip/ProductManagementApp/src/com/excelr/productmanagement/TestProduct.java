package com.excelr.productmanagement;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class TestProduct {
	
	public static void main(String[] args) {
		int productId;
		String productName;
		int productPrice;
		String productCategory;
		String productBrand;
		int productQuantity;
		HashMap<Integer, Product> products = new HashMap<Integer, Product>();//DAO
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("**********Product Management************");
			System.out.println("1) Add Product");
			System.out.println("2) Update Product");
			System.out.println("3) Delete Product");
			System.out.println("4) get Product By Id");
			System.out.println("5) get All Products");
			System.out.println("6) get All Products by price range");
			System.out.println("7) get All Products by Category");
			System.out.println("8) get All Products by brand name");
			System.out.println("9) exit");
			int option = scan.nextInt();

			switch (option) {
			case 1:
				System.out.println("Enter Product Details");
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();
				System.out.println("Enter ProductName:");
				productName = scan.next();
				System.out.println("Enter ProductPrice:");
				productPrice = scan.nextInt();
				System.out.println("Enter ProductCategory:");
				productCategory = scan.next();
				System.out.println("Enter ProductBrand:");
				productBrand = scan.next();
				System.out.println("Enter ProductQuantity:");
				productQuantity = scan.nextInt();
				Product addProduct = new Product(productId, productName, productPrice, productCategory, productBrand,
						productQuantity);
				products.put(productId, addProduct);
				System.out.println("Product Added Successfully");
				break;
			case 2:
				System.out.println("Enter Product Details For Update");
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();
				System.out.println("Enter ProductPrice:");
				productPrice = scan.nextInt();
				System.out.println("Enter ProductQuantity:");
				productQuantity = scan.nextInt();
				Product oldProduct = products.get(productId);
				oldProduct.setProductPrice(productPrice);
				oldProduct.setProductQuantity(productQuantity);

				products.put(productId, oldProduct);
				System.out.println("Product Updated Successfully");
				break;
			case 3:
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();
				products.remove(productId);
				System.out.println("Product Removed Successfully");
				break;

			case 4:
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();
				Product getProduct = products.get(productId);
				System.out.println(getProduct);
				break;

			case 5:
				Set<Integer> productKeys = products.keySet();
				Iterator<Integer> itr = productKeys.iterator();
				while (itr.hasNext()) {
					productId = itr.next();
					System.out.println(products.get(productId));
				}

				break;

			case 6:
				System.out.println("Enter Product Intial Price:");// 10000
				int intialPrice = scan.nextInt();
				System.out.println("Enter Product Final Price:");// 20000
				int finalPrice = scan.nextInt();
				productKeys = products.keySet();
				itr = productKeys.iterator();
				while (itr.hasNext()) {
					productId = itr.next();
					Product products1 = products.get(productId);
					int price = products1.getProductPrice();// 14500
					if (price >= intialPrice && price <= finalPrice)
						System.out.println(products1);
				}
				break;

			case 7:
				System.out.println("Enter ProductCategory:");
				productCategory = scan.next();
				productKeys = products.keySet();
				itr = productKeys.iterator();
				while (itr.hasNext()) {
					productId = itr.next();
					Product products1 = products.get(productId);
					if (productCategory.equals(products1.getProductCategory()))
						System.out.println(products1);
				}
				break;

			case 8:
				System.out.println("Enter ProductBrand:");
				productBrand = scan.next();
				productKeys = products.keySet();
				itr = productKeys.iterator();
				while (itr.hasNext()) {
					productId = itr.next();
					Product products1 = products.get(productId);
					if (productBrand.equals(products1.getProductBrand()))
						System.out.println(products1);
				}
				break;

			default:
				System.out.println("Thank You !!!");
				scan.close();
				System.exit(0);
				break;
			}
		}
	}

}
