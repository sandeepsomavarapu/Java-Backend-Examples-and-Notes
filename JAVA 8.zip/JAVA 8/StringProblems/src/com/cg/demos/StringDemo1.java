package com.cg.demos;

/*
 	get the third character of each string from the given string, 
 	if the third character not present append '$' and 
 	return the output in upper case
 */

public class StringDemo1 {

	public static String getChars(String array[], int input) {
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String input1[] = { "Akash", "pavan", "ac", "satish", "ram", "go" };
		int input2 = 3;
		// Output1=AV$TM$
		
		
	}

}
