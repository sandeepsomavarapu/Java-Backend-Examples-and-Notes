	package com.cg.demos;

class Product {
	int productId;
	String productName;
	double productCost;
	
	//setters, getters and constructors
}

public class StringDemo2 {
	
	public Product getProduct(String input) {
		//build the product object and return
		return null;
	}

	public String getDeliveryDetails(Product product) {
		
		/*if the product cost is >= 50000 display out out as "order will be delivered in 1 day"
		if the product cost is > 25000 and < 50000 display out out as "order will be delivered in 2 days"
		if the product cost is < 25000 display out out as "order will be delivered in 7 days"
		if the product cost is zero display out out as "invalid cost"
		*/
		return null;
	}
	public static void main(String[] args) {
		String input = "3453#laptop#54000";
	}
}
