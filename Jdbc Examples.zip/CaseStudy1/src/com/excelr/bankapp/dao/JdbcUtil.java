package com.excelr.bankapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcUtil {
	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/excelr", "root",
					"rpsconsulting");
			return conn;
		} catch (Exception exception) {
			System.out.println("Some excption");
			return null;

		}

	}
}
