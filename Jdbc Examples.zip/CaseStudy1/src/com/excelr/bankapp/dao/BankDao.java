package com.excelr.bankapp.dao;

import java.sql.SQLException;

import com.excelr.bankapp.exception.AccountNotFound;
import com.excelr.bankapp.exception.InsufficientFund;
import com.excelr.bankapp.model.Account;

public interface BankDao {

	public abstract String createAccount(Account account) throws SQLException;

	public abstract String showBalance(long accountNumber) throws AccountNotFound, SQLException;

	public abstract String makeADeposit(long accountNumber, double depositAmount) throws AccountNotFound, SQLException;

	public abstract String makeAWithdrawal(long accountNumber, double withdrawAmount)
			throws AccountNotFound, InsufficientFund, SQLException;

	public abstract String fundTransfer(long ownAccountNumber, long transferAccountNumber, double transferAmount)
			throws AccountNotFound, InsufficientFund, SQLException;

	public abstract void printTransactions(long accountNumber) throws AccountNotFound, SQLException;

	public abstract String closeAccount(long accountNumber) throws AccountNotFound, SQLException;
}
