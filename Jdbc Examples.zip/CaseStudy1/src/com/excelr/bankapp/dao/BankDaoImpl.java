package com.excelr.bankapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import com.excelr.bankapp.exception.AccountNotFound;
import com.excelr.bankapp.exception.InsufficientFund;
import com.excelr.bankapp.model.Account;

public class BankDaoImpl implements BankDao {
	Connection conn;
	PreparedStatement psmt;
	long transId;

	public BankDaoImpl() {
		conn = JdbcUtil.getConnection();
	}

	@Override
	public String createAccount(Account account) throws SQLException {// insert
		PreparedStatement psmt = conn.prepareStatement("insert into accounts values(?,?,?,?,?,?)");
		psmt.setLong(1, account.getAccountNumber());
		psmt.setString(2, account.getAccountHolderName());
		psmt.setDouble(3, account.getAccountBalance());
		psmt.setString(4, account.getAccountHolderaddress());
		psmt.setLong(5, account.getAccountHoldercontact());
		psmt.setInt(6, 0);
		int result = psmt.executeUpdate();
		if (result == 1)
			return "Your account has been created successfully";
		else
			return "somthing wrong";
	}

	@Override
	public String showBalance(long accountNumber) throws AccountNotFound, SQLException {// select

		PreparedStatement psmt = conn.prepareStatement("SELECT accountBalance FROM accounts where accountNumber=?");
		psmt.setLong(1, accountNumber);
		ResultSet result = psmt.executeQuery();
		if (result.next()) {
			return "Your Available Balance is :" + result.getDouble(1);
		} else {
			return "failed";
		}

	}

	@Override
	public String makeADeposit(long accountNumber, double depositAmount) throws AccountNotFound, SQLException {// select,update
		PreparedStatement psmt = conn.prepareStatement("SELECT accountBalance FROM accounts where accountNumber=?");
		psmt.setLong(1, accountNumber);
		ResultSet result = psmt.executeQuery();
		if (result.next()) {
			double availableBalnce = result.getDouble(1);
			double updatedBalance = availableBalnce + depositAmount;
			PreparedStatement psmt1 = conn
					.prepareStatement("update accounts set accountBalance=? where accountNumber=?");
			psmt1.setDouble(1, updatedBalance);
			psmt1.setLong(2, accountNumber);
			int result1 = psmt1.executeUpdate();
			if (result1 == 1) {
				System.out.println("transaction started");
				psmt = conn.prepareStatement("insert into transactions values(?,?,?,?,?,?,?)");
				psmt.setLong(1, ++transId);
				psmt.setLong(2, accountNumber);
				psmt.setLong(3, 0);
				psmt.setDouble(4, availableBalnce);
				psmt.setDouble(5, updatedBalance);
				psmt.setString(6, "Deposit");
				psmt.setDate(7, new Date(2023, 7, 19));
				int result2 = psmt.executeUpdate();
				if (result2 == 1) {
					return "After Deposit Avaiable Balance is: " + updatedBalance;
				} else {
					return "transaction failed";
				}

			} else {
				return "Deposit Failed"; // select,update,insert
			}
		} else {
			return "Fetch Failed"; // select,update,insert
		}
	}

	@Override
	public String makeAWithdrawal(long accountNumber, double withdrawAmount)
			throws AccountNotFound, InsufficientFund, SQLException {
		PreparedStatement psmt = conn.prepareStatement("SELECT accountBalance FROM accounts where accountNumber=?");
		psmt.setLong(1, accountNumber);
		ResultSet result = psmt.executeQuery();
		if (result.next()) {
			double availableBalnce = result.getDouble(1);
			double updatedBalance = availableBalnce - withdrawAmount;
			PreparedStatement psmt1 = conn
					.prepareStatement("update accounts set accountBalance=? where accountNumber=?");
			psmt1.setDouble(1, updatedBalance);
			psmt1.setLong(2, accountNumber);
			int result1 = psmt1.executeUpdate();
			if (result1 == 1) {
				System.out.println("transaction started");
				psmt = conn.prepareStatement("insert into transactions values(?,?,?,?,?,?,?)");
				psmt.setLong(1, ++transId);
				psmt.setLong(2, accountNumber);
				psmt.setLong(3, 0);
				psmt.setDouble(4, availableBalnce);
				psmt.setDouble(5, updatedBalance);
				psmt.setString(6, "Withdraw");
				psmt.setDate(7, new Date(2023, 7, 19));
				int result2 = psmt.executeUpdate();
				if (result2 == 1) {
					return "After Deposit Avaiable Balance is: " + updatedBalance;
				} else {
					return "transaction failed";
				}

			} else {
				return "Withdrawal Failed"; // select,update,insert
			}
		} else {
			return "Fetch Failed"; // select,update,insert
		}
	}

	@Override
	public String fundTransfer(long ownAccountNumber, long transferAccountNumber, double transferAmount)
			throws AccountNotFound, InsufficientFund, SQLException {
		PreparedStatement psmt = conn.prepareStatement("SELECT accountBalance FROM accounts where accountNumber=?");
		psmt.setLong(1, ownAccountNumber);
		ResultSet result = psmt.executeQuery();
		if (result.next()) {
			double availableBalnce = result.getDouble(1);
			double updatedBalance = availableBalnce - transferAmount;
			PreparedStatement psmt1 = conn
					.prepareStatement("update accounts set accountBalance=? where accountNumber=?");
			psmt1.setDouble(1, availableBalnce);
			psmt1.setLong(2, ownAccountNumber);
			int result1 = psmt1.executeUpdate();
			psmt = conn.prepareStatement("insert into transactions values(?,?,?,?,?,?,?)");
			psmt.setLong(1, ++transId);
			psmt.setLong(2, ownAccountNumber);
			psmt.setLong(3, transferAccountNumber);
			psmt.setDouble(4, availableBalnce);
			psmt.setDouble(5, updatedBalance);
			psmt.setString(6, "fundTransfer");
			psmt.setDate(7, new Date(2023, 7, 19));
			int result2 = psmt.executeUpdate();
			System.out.println("Transfer transaction noted...");
		}
		psmt = conn.prepareStatement("SELECT accountBalance FROM accounts where accountNumber=?");
		psmt.setLong(1, transferAccountNumber);
		result = psmt.executeQuery();
		if (result.next()) {
			double availableBalnce = result.getDouble(1);
			availableBalnce += transferAmount;
			PreparedStatement psmt1 = conn
					.prepareStatement("update accounts set accountBalance=? where accountNumber=?");
			psmt1.setDouble(1, availableBalnce);
			psmt1.setLong(2, transferAccountNumber);
			int result1 = psmt1.executeUpdate();
			if (result1 == 1) {
				return "Fund Transfer Completed";
			}
		}

		return "fund transfer completed";
	}

	@Override
	public void printTransactions(long accountNumber) throws AccountNotFound, SQLException {
		PreparedStatement psmt = conn.prepareStatement("SELECT * FROM transactions where accountNumber=?");
		psmt.setLong(1, accountNumber);
		ResultSet result = psmt.executeQuery();
		System.out.println("TransId   AccNo  ToAccNo  Balance  UpdatedBalance   TypeOfTrans  DOT");
		while (result.next()) {
			System.out.println(
					result.getLong(1) + " " + result.getLong(2) + " " + result.getLong(3) + " " + result.getDouble(4)
							+ " " + result.getDouble(5) + " " + result.getString(6) + " " + result.getDate(7));
		}
	}

	@Override
	public String closeAccount(long accountNumber) throws AccountNotFound, SQLException {
		PreparedStatement psmt1 = conn.prepareStatement("delete from accounts where accountNumber=?");
		psmt1.setLong(1, accountNumber);
		int result = psmt1.executeUpdate();
		if (result == 1) {
			return "Account Closed Successfully";
		} else {
			return "somthing went wrong...";
		}
	}

}