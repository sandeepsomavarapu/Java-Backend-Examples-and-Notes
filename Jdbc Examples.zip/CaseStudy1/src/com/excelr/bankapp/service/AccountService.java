package com.excelr.bankapp.service;

import java.sql.SQLException;

import com.excelr.bankapp.exception.AccountNotFound;
import com.excelr.bankapp.exception.InsufficientFund;
import com.excelr.bankapp.model.Account;

public interface AccountService {

	public String createAccount(Account account) throws SQLException;

	public String showBalance(long accountNumber) throws AccountNotFound, SQLException;

	public String makeADeposit(long accountNumber, double depositAmount) throws AccountNotFound, SQLException;

	public String makeAWithdrawal(long accountNumber, double withdrawAmount) throws AccountNotFound, InsufficientFund, SQLException;

	public String fundTransfer(long ownAccountNumber, long transferAccountNumber, double transferAmount)
			throws AccountNotFound, InsufficientFund, SQLException;

	public void printTransactions(long accountNumber) throws AccountNotFound, SQLException;

	public String closeAccount(long accountNumber) throws AccountNotFound, SQLException;

}