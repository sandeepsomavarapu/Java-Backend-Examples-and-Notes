package com.excelr.bankapp.service;

import java.sql.SQLException;

import com.excelr.bankapp.dao.BankDao;
import com.excelr.bankapp.dao.BankDaoImpl;
import com.excelr.bankapp.exception.AccountNotFound;
import com.excelr.bankapp.exception.InsufficientFund;
import com.excelr.bankapp.model.Account;

public class AccountServiceImpl implements AccountService {
	BankDao dao = new BankDaoImpl();

	@Override
	public String createAccount(Account account) throws SQLException {
		return dao.createAccount(account);
	}

	@Override
	public String showBalance(long accountNumber) throws AccountNotFound, SQLException {
		return dao.showBalance(accountNumber);
	}

	@Override
	public String makeADeposit(long accountNumber, double depositAmount) throws AccountNotFound, SQLException {
		return dao.makeADeposit(accountNumber, depositAmount);
	}

	@Override
	public String makeAWithdrawal(long accountNumber, double withdrawAmount) throws AccountNotFound, InsufficientFund, SQLException {
		return dao.makeAWithdrawal(accountNumber, withdrawAmount);
	}

	@Override
	public String fundTransfer(long ownAccountNumber, long transferAccountNumber, double transferAmount)
			throws AccountNotFound, InsufficientFund, SQLException {
		return dao.fundTransfer(ownAccountNumber, transferAccountNumber, transferAmount);
	}

	@Override
	public void printTransactions(long accountNumber) throws AccountNotFound, SQLException {
		dao.printTransactions(accountNumber);
	}

	@Override
	public String closeAccount(long accountNumber) throws AccountNotFound, SQLException {
		return dao.closeAccount(accountNumber);
	}
}