package com.excelr.bankapp.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.excelr.bankapp.exception.AccountNotFound;
import com.excelr.bankapp.exception.InsufficientFund;
import com.excelr.bankapp.model.Account;
import com.excelr.bankapp.service.AccountService;
import com.excelr.bankapp.service.AccountServiceImpl;

public class ClienAccount {
	public static void main(String[] args) {
		AccountService accountService = new AccountServiceImpl();
		long accountNumber;
		String accountHolderName;
		double accountBalance;
		String accountHolderaddress;
		long accountHoldercontact;

		while (true) {
			Scanner scan = new Scanner(System.in);
			System.out.println("Welcome to banking services");
			System.out.println("1. Create an Account");
			System.out.println("2. Show the Balance");
			System.out.println("3. Make a Deposit");
			System.out.println("4. Make a Withdrawal");
			System.out.println("5. Fund Transfer Within the Bank");
			System.out.println("6. Print Transactions for an Account Number");
			System.out.println("7. Close the Account");
			System.out.println("8. Exit");
			int option = scan.nextInt();
			switch (option) {
			case 1:
				try {
					System.out.println("Please enter the bank account details");
					System.out.println("Enter the accountNumber: ");
					accountNumber = scan.nextLong();
					scan.nextLine();
					System.out.println("Enter the accountHolderName: ");
					accountHolderName = scan.next();
					System.out.println("Enter the accountBalance: ");
					accountBalance = scan.nextDouble();
					System.out.println("Enter the accountHolderaddress: ");
					accountHolderaddress = scan.next();
					System.out.println("Enter the accountHoldercontact: ");
					accountHoldercontact = scan.nextLong();
					Account newAccount = new Account(accountNumber, accountHolderName, accountBalance,
							accountHolderaddress, accountHoldercontact);

					System.out.println(accountService.createAccount(newAccount));
				} catch (Exception ex) {
					System.out.println(ex);
				}
				break;
			case 2:
				try {
					System.out.println("Enter the Bank Account Number");
					accountNumber = scan.nextLong();
					System.out.println(accountService.showBalance(accountNumber));
				} catch (AccountNotFound s) {
					System.out.println("Account was not found");
				} catch (InputMismatchException s2) {
					System.out.println(s2);
				} catch (Exception s2) {
					System.out.println(s2);
				}
				break;
			case 3:
				try {
					System.out.println("Enter the Bank Account Number to make a deposit");
					accountNumber = scan.nextLong();
					System.out.println("Enter the deposit amount");
					double depositAmount = scan.nextDouble();
					System.out.println(accountService.makeADeposit(accountNumber, depositAmount));
				} catch (AccountNotFound s) {
					System.out.println("Account was not found");
				} catch (InputMismatchException s2) {
					System.out.println(s2);
				}catch(Exception ex)
				{
					System.out.println("error......."+ex);
				}
				break;
			case 4:
				try {
					System.out.println("Enter the Bank Account Number to make a withdrawal");
					accountNumber = scan.nextLong();
					System.out.println("Enter the withdrawal amount");
					double withdrawAmount = scan.nextDouble();
					System.out.println(accountService.makeAWithdrawal(accountNumber, withdrawAmount));
				} catch (AccountNotFound s) {
					System.out.println("Account was not found");
				} catch (InputMismatchException s2) {
					System.out.println(s2);
				} catch (InsufficientFund s) {
					System.out.println("Insufficient fund");
				}
				catch (Exception s) {
					System.out.println("SOme Error found");
				}
				break;
			case 5:
				try {
					System.out.println("Enter the account number of yours");
					long ownAccountNumber = scan.nextLong();
					System.out.println("Enter the account number to which money should transfer");
					long transferAccountNumber = scan.nextLong();
					System.out.println("Enter the amount to transfer");
					double transferAmount = scan.nextDouble();
					System.out.println(
							accountService.fundTransfer(ownAccountNumber, transferAccountNumber, transferAmount));
				} catch (AccountNotFound s) {
					System.out.println("Account was not found ");
				} catch (InputMismatchException s2) {
					System.out.println(s2);
				} catch (InsufficientFund s) {
					System.out.println("Insufficient fund");
				}
				 catch (Exception s) {
						System.out.println("Error....");
					}
				break;
			case 6:
				try {
					System.out.println("Enter the Bank Account Number");
					accountNumber = scan.nextLong();
					accountService.printTransactions(accountNumber);
				} catch (AccountNotFound s) {
					System.out.println("Account was not found ");
				} catch (InputMismatchException s2) {
					System.out.println(s2);
				}
				catch (Exception s2) {
					System.out.println("some error");
				}
				break;
			case 7:
				try {
					System.out.println("Enter the Bank Account Number");
					accountNumber = scan.nextLong();
					System.out.println(accountService.closeAccount(accountNumber));
				} catch (AccountNotFound s) {
					System.out.println("Account was not found ");
				} catch (InputMismatchException s2) {
					System.out.println(s2);
				}catch (Exception s2) {
					System.out.println("somthing wrong");
				}
				break;
			default:
				System.out.println("Thank You");
				scan.close();
				System.exit(0);
				break;
			}
		}
	}

}