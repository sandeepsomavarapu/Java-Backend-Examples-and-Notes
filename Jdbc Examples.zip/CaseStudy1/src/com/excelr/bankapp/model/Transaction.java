package com.excelr.bankapp.model;

import java.util.Date;

//create table transactions(transid int primary key,accountNumber int,toaccountNumber int,initialBalance decimal,updatedBalance decimal,transactionType varchar(15),trandate date);
//create table accounts(accountNumber int primary key,accountHolderName varchar(20),accountBalance decimal,
//		accountHolderaddress varchar(20),accountHoldercontact int,
//		tid int,constraint fk_tid foreign key(tid) references transactions(transid)on delete cascade);


public class Transaction {
	private long transId;
	private long accountNumber;
	private long toaccountNumber;
	private double initialBalance;
	private double updatedBalance;
	private String transactionType;
	private Date date;


	public long getTransId() {
		return transId;
	}

	public void setTransId(long transId) {
		this.transId = transId;
	}

	public long getToaccountNumber() {
		return toaccountNumber;
	}

	public void setToaccountNumber(long toaccountNumber) {
		this.toaccountNumber = toaccountNumber;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getInitialBalance() {
		return initialBalance;
	}

	public void setInitialBalance(double initialBalance) {
		this.initialBalance = initialBalance;
	}

	public double getUpdatedBalance() {
		return updatedBalance;
	}

	public void setUpdatedBalance(double updatedBalance) {
		this.updatedBalance = updatedBalance;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Transaction [transId=" + transId + ", accountNumber=" + accountNumber + ", toaccountNumber="
				+ toaccountNumber + ", initialBalance=" + initialBalance + ", updatedBalance=" + updatedBalance
				+ ", transactionType=" + transactionType + ", date=" + date + "]";
	}

	public Transaction(long transId, long accountNumber, long toaccountNumber, double initialBalance,
			double updatedBalance, String transactionType, Date date) {
		super();
		this.transId = transId;
		this.accountNumber = accountNumber;
		this.toaccountNumber = toaccountNumber;
		this.initialBalance = initialBalance;
		this.updatedBalance = updatedBalance;
		this.transactionType = transactionType;
		this.date = date;
	}

	public Transaction() {
		// TODO Auto-generated constructor stub
	}

}