package com.excelr.bankapp.exception;

@SuppressWarnings("serial")
public class InsufficientFund extends Exception {

	public InsufficientFund(String MSG) 
	{
		super(MSG);
	}
}