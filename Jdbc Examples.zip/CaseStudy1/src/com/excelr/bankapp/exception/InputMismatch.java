package com.excelr.bankapp.exception;
import java.util.InputMismatchException;

@SuppressWarnings("serial")
public class InputMismatch extends InputMismatchException{
	public InputMismatch(String message)
	{
		super(message);
	}
}