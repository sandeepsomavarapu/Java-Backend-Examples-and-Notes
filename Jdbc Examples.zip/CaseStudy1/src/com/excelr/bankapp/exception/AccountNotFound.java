package com.excelr.bankapp.exception;


public class AccountNotFound extends Exception {

	public AccountNotFound(String MSG)
	{
		super(MSG);
	}
}