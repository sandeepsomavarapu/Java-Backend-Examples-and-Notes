package com.excelr.productapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class TestProduct {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		int productId;
		String productName;
		int productPrice;
		String productCategory;
		String productBrand;
		int productQuantity;
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/excelr", "root", "rpsconsulting");
		PreparedStatement psmt;
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("**********Product Management************");
			System.out.println("1) Add Product");
			System.out.println("2) Update Product");
			System.out.println("3) Delete Product");
			System.out.println("4) get Product By Id");
			System.out.println("5) get All Products");
			System.out.println("6) get All Products by price range");
			System.out.println("7) get All Products by Category");
			System.out.println("8) get All Products by brand name");
			System.out.println("9) exit");
			int option = scan.nextInt();

			switch (option) {
			case 1:
				System.out.println("Enter Product Details");
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();
				System.out.println("Enter ProductName:");
				productName = scan.next();
				System.out.println("Enter ProductPrice:");
				productPrice = scan.nextInt();
				System.out.println("Enter ProductCategory:");
				productCategory = scan.next();
				System.out.println("Enter ProductBrand:");
				productBrand = scan.next();
				System.out.println("Enter ProductQuantity:");
				productQuantity = scan.nextInt();
				psmt = conn.prepareStatement("insert into products_info values(?,?,?,?,?,?)");
				psmt.setInt(1, productId);
				psmt.setString(2, productName);
				psmt.setInt(3, productPrice);
				psmt.setString(4, productCategory);
				psmt.setString(5, productBrand);
				psmt.setInt(6, productQuantity);
				int result = psmt.executeUpdate();
				if (result > 0) {
					System.out.println("Product Inserted Successfully");
				}
				break;
			case 2:
				System.out.println("Enter Product Details For Update");
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();
				System.out.println("Enter ProductPrice:");
				productPrice = scan.nextInt();
				System.out.println("Enter ProductQuantity:");
				productQuantity = scan.nextInt();
				psmt = conn.prepareStatement(
						"update products_info set productPrice=?,productQuantity=? where productId=?");
				psmt.setInt(1, productPrice);
				psmt.setInt(2, productQuantity);
				psmt.setInt(3, productId);
				result = psmt.executeUpdate();
				if (result == 1) {
					System.out.println("Product Updated Successfully");
				}
				break;
			case 3:
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();
				psmt = conn.prepareStatement("delete from products_info where productId=?");
				psmt.setInt(1, productId);
				result = psmt.executeUpdate();//1
				if (result == 1) {
					System.out.println("Product Deleted Successfully");
				}
				break;

			case 4:
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();
				psmt = conn.prepareStatement("select *  from products_info where productId=?");
				psmt.setInt(1, productId);
				ResultSet resultset = psmt.executeQuery();
				if (resultset.next()) {
					System.out.println(resultset.getInt(1) + " " + resultset.getString(2) + " " + resultset.getString(3)
							+ " " + resultset.getString(4) + " " + resultset.getString(5) + " " + resultset.getInt(6));
				}
				break;

			case 5:
				psmt = conn.prepareStatement("select *  from products_info");
				resultset = psmt.executeQuery();
				while (resultset.next()) {
					System.out.println(resultset.getInt(1) + " " + resultset.getString(2) + " " + resultset.getString(3)
							+ " " + resultset.getString(4) + " " + resultset.getString(5) + " " + resultset.getInt(6));
				}

				break;

			case 6:
				System.out.println("Enter Product Intial Price:");// 10000
				int intialPrice = scan.nextInt();
				System.out.println("Enter Product Final Price:");// 20000
				int finalPrice = scan.nextInt();
				psmt = conn.prepareStatement("select *  from products_info where productPrice between ? and ?");
				psmt.setInt(1, intialPrice);
				psmt.setInt(2, finalPrice);
				resultset = psmt.executeQuery();
				while (resultset.next()) {
					System.out.println(resultset.getInt(1) + " " + resultset.getString(2) + " " + resultset.getString(3)
							+ " " + resultset.getString(4) + " " + resultset.getString(5) + " " + resultset.getInt(6));
				}
				break;

			case 7:
				System.out.println("Enter ProductCategory:");
				productCategory = scan.next();
				psmt = conn.prepareStatement("select *  from products_info where productCategory=?");
				psmt.setString(1, productCategory);
				resultset = psmt.executeQuery();
				while (resultset.next()) {
					System.out.println(resultset.getInt(1) + " " + resultset.getString(2) + " " + resultset.getString(3)
							+ " " + resultset.getString(4) + " " + resultset.getString(5) + " " + resultset.getInt(6));
				}
				break;

			case 8:
				System.out.println("Enter ProductBrand:");
				productBrand = scan.next();
				psmt = conn.prepareStatement("select *  from products_info where productBrand=?");
				psmt.setString(1, productBrand);
				resultset = psmt.executeQuery();
				while (resultset.next()) {
					System.out.println(resultset.getInt(1) + " " + resultset.getString(2) + " " + resultset.getString(3)
							+ " " + resultset.getString(4) + " " + resultset.getString(5) + " " + resultset.getInt(6));
				}
				break;
			default:
				System.out.println("Thank You !!!");
				scan.close();
				System.exit(0);
				break;
			}
		}
	}

}
