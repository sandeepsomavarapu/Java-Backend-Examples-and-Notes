package com.excelr.productapp;

//create table products_info(productId int,productName varchar(20),productPrice int,productCategory varchar(20),productBrand varchar(20),productQuantity int);
//insert into products_info values(112,"dell",26000,'electronics',"dellorg",44);
//insert into products_info values(113,"MI",14999,'electronics',"redmi",14);
//insert into products_info values(114,"bluestar",28999,'consumer',"koria",12);
//insert into products_info values(115,"teddybare",26000,'electronics',"amazon",43);
//insert into products_info values(116,"ipads",26000,'consumer',"apple",44);

public class Product {
	private int productId;
	private String productName;
	private int productPrice;
	private String productCategory;
	private String productBrand;
	private int productQuantity;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProductBrand() {
		return productBrand;
	}

	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public Product() {
		System.out.println("am from default constructor");
	}

	public Product(int productId, String productName, int productPrice, String productCategory, String productBrand,
			int productQuantity) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCategory = productCategory;
		this.productBrand = productBrand;
		this.productQuantity = productQuantity;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productCategory=" + productCategory + ", productBrand=" + productBrand + ", productQuantity="
				+ productQuantity + "]";
	}

}
