package com.excelr.jdbcdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DDL_Ex {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
//		1)Register the driver class	
		Class.forName("com.mysql.cj.jdbc.Driver");
//		2)Create the connection
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/excelr", "root", "rpsconsulting");
//		3)create statement	Statement,PrepareStatement,CallableStatement(PLSQL)
			Statement stmt=	conn.createStatement();
//		4)execute querys	DDL-->create,alter,drop,truncate,rename--execute()   DML-->i,u,d-->executeUpdate()    DRL-->select-->executeQuery()
			int result=	stmt.executeUpdate("insert into emps_info values(123,'sleeping',23000,'hyderabad')");
//		5)close the connection
				conn.close();
				System.out.println(result+"data inserted ....");
	}

}
