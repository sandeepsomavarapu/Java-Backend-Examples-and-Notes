package com.excelr.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Drl_Ex {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
//		1)Register the driver class
		Class.forName("com.mysql.cj.jdbc.Driver");
//		2)Create the connection
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/excelr", "root", "rpsconsulting");
//		3)create statement,preparedStatement,CallableStatement
		Statement stmt = conn.createStatement();
//		4)execute querys		execute()-->DDL,executeUpdate()-->DML,executeQuery()--->DRL
		ResultSet result = stmt.executeQuery("select * from users");

//		5)close the connection
		while (result.next()) {
			System.out.println(result.getInt(1) + " " + result.getString("uname") + " " + result.getString(3));
		}
		conn.close();

	}

}
