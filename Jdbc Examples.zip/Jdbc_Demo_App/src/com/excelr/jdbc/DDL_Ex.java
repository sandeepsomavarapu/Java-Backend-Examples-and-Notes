package com.excelr.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DDL_Ex {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {

//		1)Register the driver class
		Class.forName("com.mysql.cj.jdbc.Driver");
//		2)Create the connection
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/excelr", "root", "rpsconsulting");
//		3)create statement,preparedStatement,CallableStatement
		Statement stmt = conn.createStatement();
//		4)execute querys		execute()-->DDL,executeUpdate()-->DML,executeQuery()--->DRL
		boolean result = stmt.execute("create table users(uid int,uname varchar(10),fullname varchar(20))");
//		5)close the connection
		System.out.println("table created.." + result);
		conn.close();

	}

}
