package com.excelr.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Dml_Ex {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
//		1)Register the driver class
		Class.forName("com.mysql.cj.jdbc.Driver");
//		2)Create the connection
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/excelr", "root", "rpsconsulting");
//		3)create statement,preparedStatement,CallableStatement
		Statement stmt = conn.createStatement();
//		4)execute querys		execute()-->DDL,executeUpdate()-->DML,executeQuery()--->DRL
		//int result = stmt.executeUpdate("insert into users values(1123,'suresh123','sureshg')");
	//	int result = stmt.executeUpdate("update users set fullname='sandeepsoma' where uid=1122");
		int result = stmt.executeUpdate("delete from users where uid=1123");

//		5)close the connection
		System.out.println("Data deleted :" + result);
		conn.close();

	}

}
