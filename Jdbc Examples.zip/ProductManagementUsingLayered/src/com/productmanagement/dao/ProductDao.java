package com.productmanagement.dao;

import java.util.List;

import com.productmanagement.exception.ProductNotFound;
import com.productmanagement.model.Product;

public interface ProductDao {
	public abstract String addProduct(Product product);

	public abstract String updateProduct(Product product);

	public abstract String deleteProduct(int productId);

	public abstract Product getProductById(int productId) throws ProductNotFound;

	public abstract List<Product> getAllProducts();

	public abstract List<Product> getAllProductsByPriceRange(int intialPrice, int finalPrice);

	public abstract List<Product> getAllProductsByCategory(String category);

	public abstract List<Product> getAllProductsByBrandName(String brandName);
}
