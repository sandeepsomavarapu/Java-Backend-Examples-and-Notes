package com.productmanagement.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.productmanagement.exception.ProductNotFound;
import com.productmanagement.model.Product;

public class ProductDaoImpl implements ProductDao {
	HashMap<Integer, Product> products = new HashMap<Integer, Product>();

	@Override
	public String addProduct(Product product) {
		products.put(product.getProductId(), product);
		return "Product Inserted Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		products.put(product.getProductId(), product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		products.remove(productId);
		return "Product Removed Successfully";
	}

	@Override
	public Product getProductById(int productId) throws ProductNotFound {
		Product product = products.get(productId);
		if (product != null)
			return product;
		else
			throw new ProductNotFound("Enter Valid ProductId:....");
	}

	@Override
	public List<Product> getAllProducts() {
		ArrayList<Product> al = new ArrayList<Product>();
		Set<Integer> productKeys = products.keySet();
		Iterator<Integer> itr = productKeys.iterator();
		while (itr.hasNext()) {
			int productId = itr.next();
			al.add(products.get(productId));
		}
		return al;
	}

	@Override
	public List<Product> getAllProductsByPriceRange(int intialPrice, int finalPrice) {
		ArrayList<Product> al = new ArrayList<Product>();
		Set<Integer> productKeys = products.keySet();
		Iterator<Integer> itr = productKeys.iterator();

		while (itr.hasNext()) {
			int productId = itr.next();
			Product products1 = products.get(productId);
			int price = products1.getProductPrice();// 14500
			if (price >= intialPrice && price <= finalPrice)
				al.add(products.get(productId));
		}
		return al;
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {

		ArrayList<Product> al = new ArrayList<Product>();
		Set<Integer> productKeys = products.keySet();
		Iterator<Integer> itr = productKeys.iterator();
		while (itr.hasNext()) {
			int productId = itr.next();
			Product products1 = products.get(productId);
			if (category.equals(products1.getProductCategory()))
				al.add(products1);
		}
		return al;
	}

	@Override
	public List<Product> getAllProductsByBrandName(String brandName) {

		ArrayList<Product> al = new ArrayList<Product>();
		Set<Integer> productKeys = products.keySet();
		Iterator<Integer> itr = productKeys.iterator();
		while (itr.hasNext()) {
			int productId = itr.next();
			Product products1 = products.get(productId);
			if (brandName.equals(products1.getProductBrand()))
				al.add(products1);
		}
		return al;
	}

}
