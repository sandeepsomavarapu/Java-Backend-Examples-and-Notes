package com.productmanagement.ui;

import java.util.List;
import java.util.Scanner;

import com.productmanagement.exception.ProductNotFound;
import com.productmanagement.model.Product;
import com.productmanagement.service.ProductService;
import com.productmanagement.service.ProductServiceImpl;

public class ProductClient {

	public static void main(String[] args) {
		ProductService service = new ProductServiceImpl();
		int productId;
		String productName;
		int productPrice;
		String productCategory;
		String productBrand;
		int productQuantity;
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("**********Product Management************");
			System.out.println("1) Add Product");
			System.out.println("2) Update Product");
			System.out.println("3) Delete Product");
			System.out.println("4) get Product By Id");
			System.out.println("5) get All Products");
			System.out.println("6) get All Products by price range");
			System.out.println("7) get All Products by Category");
			System.out.println("8) get All Products by brand name");
			System.out.println("9) exit");
			int option = scan.nextInt();

			switch (option) {
			case 1:
				System.out.println("Enter Product Details");
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();
				System.out.println("Enter ProductName:");
				productName = scan.next();
				System.out.println("Enter ProductPrice:");
				productPrice = scan.nextInt();
				System.out.println("Enter ProductCategory:");
				productCategory = scan.next();
				System.out.println("Enter ProductBrand:");
				productBrand = scan.next();
				System.out.println("Enter ProductQuantity:");
				productQuantity = scan.nextInt();
				Product addProduct = new Product(productId, productName, productPrice, productCategory, productBrand,
						productQuantity);
				System.out.println(service.addProduct(addProduct));
				break;
			case 2:
				System.out.println("Enter Product Details For Update");
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();
				System.out.println("Enter ProductPrice:");
				productPrice = scan.nextInt();
				System.out.println("Enter ProductQuantity:");
				productQuantity = scan.nextInt();
				Product oldProduct = null;
				try {
					oldProduct = service.getProductById(productId);
				} catch (ProductNotFound e) {
					System.out.println("product id not valid....");
				}
				oldProduct.setProductPrice(productPrice);
				oldProduct.setProductQuantity(productQuantity);
				System.out.println(service.updateProduct(oldProduct));

				break;
			case 3:
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();
				System.out.println(service.deleteProduct(productId));
				break;

			case 4:
				System.out.println("Enter ProductId:");
				productId = scan.nextInt();

				try {
					System.out.println(service.getProductById(productId));
				} catch (ProductNotFound e) {
					System.out.println("Productid is invalid....");
				}
				break;

			case 5:
				List<Product> products = service.getAllProducts();
				for (Product product : products)
					System.out.println(product);
				break;

			case 6:
				System.out.println("Enter Product Intial Price:");// 10000
				int intialPrice = scan.nextInt();
				System.out.println("Enter Product Final Price:");// 20000
				int finalPrice = scan.nextInt();
				products = service.getAllProductsByPriceRange(intialPrice, finalPrice);
				for (Product product : products)
					System.out.println(product);
				break;
			case 7:
				System.out.println("Enter ProductCategory:");
				productCategory = scan.next();
				products = service.getAllProductsByCategory(productCategory);
				for (Product product : products)
					System.out.println(product);
				break;

			case 8:
				System.out.println("Enter ProductBrand:");
				productBrand = scan.next();
				products = service.getAllProductsByBrandName(productBrand);
				for (Product product : products)
					System.out.println(product);
				break;

			default:
				System.out.println("Thank You !!!");
				scan.close();
				System.exit(0);
				break;
			}
		}
	}

}