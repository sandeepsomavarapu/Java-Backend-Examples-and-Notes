package com.productmanagement.service;

import java.util.List;

import com.productmanagement.dao.ProductDao;
import com.productmanagement.dao.ProductDaoImpl;
import com.productmanagement.exception.ProductNotFound;
import com.productmanagement.model.Product;

public class ProductServiceImpl implements ProductService {

	ProductDao dao = new ProductDaoImpl();

	@Override
	public String addProduct(Product product) {

		return dao.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {

		return dao.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {

		return dao.deleteProduct(productId);
	}

	@Override
	public Product getProductById(int productId) throws ProductNotFound {

		return dao.getProductById(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return dao.getAllProducts();
	}

	@Override
	public List<Product> getAllProductsByPriceRange(int intialPrice, int finalPrice) {

		return dao.getAllProductsByPriceRange(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {

		return dao.getAllProductsByCategory(category);
	}

	@Override
	public List<Product> getAllProductsByBrandName(String brandName) {

		return dao.getAllProductsByBrandName(brandName);
	}

}
