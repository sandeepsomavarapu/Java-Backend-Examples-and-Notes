package com.Threads;
class Xyz extends Thread 
{
	public void run()
	{
		System.out.println("Thread-1");
		System.out.println(Thread.currentThread());//[thread-1,5,main]
		System.out.println("after setName");
		Thread.currentThread().setName("db");
		System.out.println(Thread.currentThread().getName());
		Thread.currentThread().setPriority(4);
		System.out.println(Thread.currentThread());//[sandeep,4,main]
	}	
}
class MainThread
{
	public static void main(String[] args) 
	{
		//System.out.println(Thread.currentThread());//[main,5,main]
	
		Xyz x=new Xyz();
		x.start();//run
		//x.run();
	}
	}