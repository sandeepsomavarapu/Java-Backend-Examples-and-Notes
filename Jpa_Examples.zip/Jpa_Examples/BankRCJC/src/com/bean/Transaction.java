package com.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Transct")
public class Transaction{

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name="transId",length=15)
    int transId;
    @Column(name="Acct",length=15)
	int accNo;
    @Column(name="Amount",length=15)
	int amount;
	@Column(name="transactionType",length=15)
	String transactionType;
	
	
    public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
} 