package com.bean;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="BankJpa")

public class BankDetails {
	
	@Column(name="Acct",length=15)
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	@SequenceGenerator(name="seq", sequenceName="acct_seq")
	@Id
	int acct;
	@Column(name="Email",length=25)
	String email;
	@Column(name="Password",length=15)
	String password;
	@Column(name="Name",length=25)
	String name;
	@Column(name="PhoneNo",length=10)
	String phno;
	@Column(name="Address",length=15)
	String  address;
	@Column(name="Amount",length=10)
    int amount;
    @OneToOne
    private Transaction TransId;
	

	public Transaction getTransId() {
		return TransId;
	}
	public void setTransId(Transaction transId) {
		TransId = transId;
	}
	/*public BankDetails(String email,String password,String name,String phno,String  address){
		this.email = email;
		this.password = password; 
		this.name = name;
		this.phno = phno;
		this.address = address;
	}*/
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhno() {
		return phno;
	}
	public void setPhno(String phno) {
		this.phno = phno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAcct() {
		return acct;
	}
	public void setAcct(int acct) {
		this.acct = acct;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
}
