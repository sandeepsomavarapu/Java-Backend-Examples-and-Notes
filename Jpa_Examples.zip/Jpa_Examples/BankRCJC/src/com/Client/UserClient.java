package com.Client;

import java.util.Scanner;

import com.bean.BankDetails;
import com.bean.Transaction;
import com.dao.Dao;

public class UserClient {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Dao dao =  new Dao();
		BankDetails bankd = new BankDetails();
		Transaction ts = new Transaction(); 
		while(true){
		System.out.println("***************RCJCUK Bank****************");
		System.out.println("1:Register \n2:Login");
		System.out.println("************************************************");
		System.out.println("Enter your choice :");

		int n = sc.nextInt();
		switch (n) {
		case 1:
		
		System.out.println("Enter Your E-mail");
		String mail = sc.next();
		bankd.setEmail(mail);
		System.out.println("Set Your password");
		String passw = sc.next();
		bankd.setPassword(passw);
		System.out.println("Enter Your Name");
		String name = sc.next();
		bankd.setName(name);
		System.out.println("Enter Your Mobile No.");
	    String phno = sc.next();
	    bankd.setPhno(phno);
	    System.out.println("Enter Your Address");
	    String add = sc.next();
	    bankd.setAddress(add);
	    bankd.setAmount(500);
	    dao.register(bankd);
	  break;
		case 2:
		
			System.out.println("Enter Userid");
			String user=sc.next();
			System.out.println("Enter password");
			String password=sc.next();
			boolean a = dao.login(user, password);
			
			if(a==true){
				System.out.println("**********************************************");
				System.out.println(" Logged In Succesfully ");
				while(true){
					System.out.println("\n-----------------------");
				System.out.println("1:View Balance \n2:Deposit \n3:Withdraw \n4:Transfer \n5:Print Transactions\n6:User Profile\n7:Exit");
				System.out.println("************************************************");
				System.out.println("Select any Operation : ");
				int ch = sc.nextInt();	
				switch (ch) {
				
				case 1:
					dao.view(user);
					break;
				case 2:
					System.out.println(user);
					System.out.println("Enter Amount to Deposit ");
					int amt = sc.nextInt();
					
					dao.deposit(user, amt);
					break;
				case 3:
					System.out.println("Enter Amount to withdaw");
					int amt1 = sc.nextInt();		
					dao.withdraw(user, amt1);
					break;
				case 4:
					System.out.println("Enter Account number To Transfer");
					int acct = sc.nextInt();
					System.out.println("Enter Amount to transfer");
					int tamt = sc.nextInt();
					dao.transfer(user, acct, tamt);
					break;
				case 5:
					System.out.println("Transactions");
					dao.transactions(user);
					break;
				case 6:
					System.out.println("Your Profile Details");
					System.out.println("--------------------");
					dao.profile(user);
					break;
				case 7:
					System.out.println("Thanks for using Our Application");
					System.exit(0);
					break;
				}
				}
			}else{
				System.out.println("Please enter valid choice else to exit press 6 ");
			}
			break;
		}
	}
	}
}