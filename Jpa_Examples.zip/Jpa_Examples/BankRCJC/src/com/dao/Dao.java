package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.bean.BankDetails;
import com.bean.Transaction;

public class Dao {
	Transaction ts = new Transaction();
	Transaction ts1 = new Transaction();
	Transaction ts2 = new Transaction();
	private EntityManager entityManager;
	public Dao() {
		entityManager = JpaUtil.getEntityManager();
	}
	public void register(BankDetails bankd){
		entityManager.getTransaction().begin();
		entityManager.persist(bankd);	
		entityManager.getTransaction().commit();
	}
	
	public boolean login(String email,String password) {
		Query q = entityManager.createQuery("select b from BankDetails b");
		List<BankDetails> l = q.getResultList();
		for(BankDetails b1:l){
		//System.out.println(b1.getEmail());
		if(email.equals(b1.getEmail())&&password.equals(b1.getPassword()))
		{
			return true;
		}
		}
		return false;	
	}
	
	public void view(String userid) {
		Query q1 = entityManager.createQuery("select b from BankDetails b where b.email=:user");
		q1.setParameter("user",userid);
		List<BankDetails> l1 = q1.getResultList();
		for(BankDetails b2:l1){
			System.out.print("Your Current Available Balance : ");
		System.out.println(b2.getAmount());
		
		
	}
}
	public void deposit(String userid,int amt) {
		Query q1 = entityManager.createQuery("select b from BankDetails b where b.email=:user");
		q1.setParameter("user",userid);
		List<BankDetails> l1 = q1.getResultList();
		for(BankDetails b3:l1){
			int act = b3.getAcct();
			b3.setTransId(ts);
			int bal = b3.getAmount();
			bal = bal + amt;
			System.out.println(" Money Deposited Succesfully -_-");
			System.out.print("Available Balance After Deposit : " +bal+ "\n");
			b3.setAmount(bal);
			int acc = b3.getAcct();
			entityManager.getTransaction().begin();
			ts.setAmount(amt);
			ts.setTransactionType(" Deposit ");
			ts.setAccNo(act);
			entityManager.merge(b3);
			entityManager.persist(ts);
			entityManager.getTransaction().commit();
			
		}
		}
	public void withdraw(String userid1,int amt) {
		Query q1 = entityManager.createQuery("select b from BankDetails b where b.email=:user");
		q1.setParameter("user",userid1);
		List<BankDetails> l1 = q1.getResultList();
		for(BankDetails b3:l1){	
			int bal = b3.getAmount();
			int act = b3.getAcct();
			b3.setTransId(ts1);
			int acc= b3.getAcct();
			bal = bal - amt;
			System.out.print("After Withdrawal Remaining Balance : " +bal);
			entityManager.getTransaction().begin();
			b3.setAmount(bal);
			ts1.setAmount(amt);
			ts1.setTransactionType(" Withdraw ");
			ts1.setAccNo(act);
			
			
			
			entityManager.merge(b3);
			entityManager.persist(ts1);
			entityManager.getTransaction().commit();
			
		}
		}
	public void transfer(String userid1,int acct,int tamt){
		Query q1 = entityManager.createQuery("select b from BankDetails b where b.email=:user");
		q1.setParameter("user",userid1);
		List<BankDetails> l1 = q1.getResultList();
		for(BankDetails b3:l1){
			int bal = b3.getAmount();
			int act = b3.getAcct();
			b3.setTransId(ts2);
			int acc= b3.getAcct();
			bal = bal - tamt;
			BankDetails bk=new BankDetails();
			bk=entityManager.find(BankDetails.class, acct);
					
			System.out.println("Money Transfer Success");
			System.out.println("Hello You Have Just Transferred Rs." +tamt+ " to "+bk.getName() +" whose account No. is "+acc);
			System.out.print("Your Current Available Balance In Your Accouont is : " +bal);
			entityManager.getTransaction().begin();
			b3.setAmount(bal);
			ts2.setAmount(tamt);
			ts2.setTransactionType(" Transfer ");
			ts2.setAccNo(act);
		
			entityManager.merge(b3);
			entityManager.persist(ts2);
			entityManager.getTransaction().commit();
			
		}
		/*Query qq = entityManager.createQuery("select b from BankDetails b where b.acct=:tacct");
		qq.setParameter("tacct",acct);
		List<BankDetails> l2 = q1.getResultList();
		for(BankDetails b4:l2){
			int bal1 = b4.getAmount();
			bal1 = bal1 + tamt;
			b4.setAmount(bal1);
			entityManager.getTransaction().begin();
			entityManager.merge(b4);
			entityManager.getTransaction().commit();
		}*/
		
		BankDetails b = new BankDetails();
		b = entityManager.find(BankDetails.class, acct);
		int bal1 = b.getAmount();
		bal1 = bal1 + tamt;
		b.setAmount(bal1);
		entityManager.getTransaction().begin();
		entityManager.merge(b);
		entityManager.getTransaction().commit();
	}
	public void transactions(String id){
		Query q1 = entityManager.createQuery("select b from BankDetails b where b.email=:user");
		q1.setParameter("user",id);
		List<BankDetails> l1 = q1.getResultList();
		for(BankDetails b3:l1){
			int acc = b3.getAcct();	
			System.out.println(acc);
		Query qr = entityManager.createQuery("select t from Transaction t where t.accNo=:act");
		qr.setParameter("act",acc);
		List<Transaction> li = qr.getResultList();
		System.out.println("TransactionId	 Amount   	TrasactionType   "	);
		System.out.println("-------------------------------------------------");
		for(Transaction tr:li){
			System.out.println("\t" +tr.getTransId()+ "\t    "+tr.getAmount()+"\t       "+tr.getTransactionType());
		}
	}
}
	public void profile(String id) {
		Query q1 = entityManager.createQuery("select b from BankDetails b where b.email=:user");
		q1.setParameter("user",id);
		List<BankDetails> l1 = q1.getResultList();
		for(BankDetails b3:l1){
		System.out.println("\nAccountNo: "+b3.getAcct()+"\nName: "+b3.getName()+"\nPhoneNo: "+b3.getPhno()+"\nEmail: "+b3.getEmail());
		System.out.println("Balance: "+b3.getAmount());
		}

		}
}