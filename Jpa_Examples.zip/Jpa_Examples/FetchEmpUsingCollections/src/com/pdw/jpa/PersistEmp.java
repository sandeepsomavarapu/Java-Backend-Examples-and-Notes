package com.pdw.jpa;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
public class PersistEmp {  
     
   public static void main(String args[])  
   {  
EntityManagerFactory emf=Persistence.createEntityManagerFactory("FetchEmpUsingCollections");  
       EntityManager em=emf.createEntityManager(); 
       
    Query q= em.createQuery("select e from Employee e");

    		List<Employee> l=	q.getResultList();
    		
    		for(Employee emp:l)
    		{
    			System.out.print(emp.getEid());
    			System.out.print(emp.getEname());
    			System.out.print(emp.getEsal());
    			System.out.println(emp.getEadd());
    		}
    
    
    
    
       em.close();  
       emf.close();  
         
   }  
} 