package com.pdw.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
public static void main(String[] args) {
	
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("akash");
	EntityManager em=emf.createEntityManager();
	em.getTransaction().begin();
	Employee emp=new Employee(12, "qwerty",1200);
			
	em.persist(emp);
	
	em.getTransaction().commit();
	
	
	/*Employee emp=em.find(Employee.class,123);

	System.out.println(emp.getEmpname());
	*/
	
}
}
