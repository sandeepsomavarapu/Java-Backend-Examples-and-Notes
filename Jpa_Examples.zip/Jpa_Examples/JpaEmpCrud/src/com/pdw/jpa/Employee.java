package com.pdw.jpa;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity//
@Table(name="Jpaemp")
public class Employee {
	@Id
	@Column(name="eid",length=20)
	private int empid;
	@Column(name="ename",length=20)
	private String empname;
	@Column(name="salary",length=20)
	private int esal;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getEsal() {
		return esal;
	}
	public void setEsal(int esal) {
		this.esal = esal;
	}

public Employee(int empid, String empname, int esal) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.esal = esal;
	}
public Employee() {
	// TODO Auto-generated constructor stub
}
}
