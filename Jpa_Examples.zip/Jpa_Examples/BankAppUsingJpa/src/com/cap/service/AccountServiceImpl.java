package com.cap.service;

import com.cap.dao.AccountDao;
import com.cap.dao.AccountDaoImpl;
import com.cap.entity.Account;

public class AccountServiceImpl implements AccountService {
AccountDao dao=new AccountDaoImpl();
	@Override
	public int createAccount(Account account) {
	int accNo=dao.createAccount(account);
		return accNo;
	}
	@Override
	public Account displayAccount(int accNo) {
	Account account=dao.displayAccount(accNo);
		return account;
	}
}
