package com.cap.service;

import com.cap.entity.Account;

public interface AccountService 
{
	int	createAccount(Account emp);	//persist ,merge,remove
	Account displayAccount(int empId);//find
}
