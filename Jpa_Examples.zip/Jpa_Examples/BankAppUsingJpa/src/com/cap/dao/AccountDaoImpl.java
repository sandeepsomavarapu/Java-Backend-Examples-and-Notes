package com.cap.dao;

import javax.persistence.EntityManager;

import com.cap.entity.Account;

public class AccountDaoImpl implements AccountDao {

	EntityManager entity = UtilJava.getEntityManager();

	@Override
	public int createAccount(Account account) {
		entity.getTransaction().begin();
		entity.persist(account);
		int accNum = account.getAccNum();
		entity.getTransaction().commit();
		return accNum;
	}

	@Override
	public Account displayAccount(int accNum) {
		Account account = entity.find(Account.class, accNum);
		return account;
	}

}
