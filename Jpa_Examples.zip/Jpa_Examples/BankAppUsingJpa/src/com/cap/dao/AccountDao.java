package com.cap.dao;

import com.cap.entity.Account;

public interface AccountDao 
{

	int	createAccount(Account emp);
	
	Account displayAccount(int empId);
	
}
