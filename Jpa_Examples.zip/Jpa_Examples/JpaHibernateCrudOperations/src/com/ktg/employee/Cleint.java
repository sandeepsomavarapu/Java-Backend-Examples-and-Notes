package com.ktg.employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Cleint {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("postgres");
		
		EntityManager em=factory.createEntityManager();
		
					Employee emp=em.find(Employee.class,123);//select * from emp where eid=125
							
								
		
		
		//Employee emp=new Employee(125,"sandeep","hyd",28,1000);
		
		//dml  
		em.getTransaction().begin();
		em.remove(emp);
		//em.merge(emp);
	//	em.persist(emp);//ORM insert
		em.getTransaction().commit();
		em.close();
		factory.close();
	}

}
