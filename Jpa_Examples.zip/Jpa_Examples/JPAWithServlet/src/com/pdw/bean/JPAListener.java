package com.pdw.bean;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class JPAListener implements ServletContextListener {
	 public void contextInitialized(ServletContextEvent e) {
	       
	        EntityManagerFactory emf =
	            Persistence.createEntityManagerFactory("JPQLCRUD");
	        e.getServletContext().setAttribute("emf", emf);
	    }
	 
	    // Release the EntityManagerFactory:
	    public void contextDestroyed(ServletContextEvent e) {
	        EntityManagerFactory emf =
	            (EntityManagerFactory)e.getServletContext().getAttribute("emf");
	        emf.close();
	    }
}
