package com.pdw.bean;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/WelcomeServlet")
public class WelcomeServlet extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		  EntityManagerFactory emf =
		           (EntityManagerFactory)getServletContext().getAttribute("emf");
		        EntityManager em = emf.createEntityManager();
	       em.getTransaction().begin(); 
	       Employee e=new Employee();
	       e.setEid(1);
	       e.setEname(request.getParameter("a"));
	       e.setEsal(1000);
		em.persist(e);
	       em.getTransaction().commit(); 

	       em.close();  
	       emf.close();  
		
	}
}
