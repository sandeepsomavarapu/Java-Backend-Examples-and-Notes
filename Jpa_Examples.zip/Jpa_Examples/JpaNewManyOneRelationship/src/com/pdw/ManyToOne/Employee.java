package com.pdw.ManyToOne;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "employees")
public class Employee {
	@Id
	@Column(length = 10)
	@GeneratedValue
	private int eid;
	@Column(length = 10)
	private String ename;
	@Column(length = 10)
	private String address;
	@Column(length = 10)
	private int esal;
	@ManyToOne
	@OnDelete(action=OnDeleteAction.CASCADE)
	private Department dept;
	
	public Employee(String ename, String address, int esal, Department dept) {
		super();
		this.ename = ename;
		this.address = address;
		this.esal = esal;
		this.dept = dept;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getEsal() {
		return esal;
	}

	public void setEsal(int esal) {
		this.esal = esal;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

}
