package com.pdw.ManyToOne;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="dept")
public class Department {
	@Id
	@GeneratedValue 
	@Column(length=10)
	private int deptno;
	@Column(length=12)
	private String dname;
	@Column(length=12)
	private String dloc;
	public Department() {
		// TODO Auto-generated constructor stub
	}
	public Department(String dname, String dloc) {
		super();
		this.dname = dname;
		this.dloc = dloc;
	}
	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getDloc() {
		return dloc;
	}

	public void setDloc(String dloc) {
		this.dloc = dloc;
	}}
