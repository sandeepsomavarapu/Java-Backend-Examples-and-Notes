package com.cg;

import org.junit.jupiter.api.Test;

import com.cg.jpacrud.dao.EmployeeDao;
import com.cg.jpacrud.dao.EmployeeDaoImpl;
import com.cg.jpacrud.entities.Employee;

import junit.framework.TestCase;
public class AppTest extends TestCase {
	EmployeeDao dao=new EmployeeDaoImpl();
			@Test
		public void	checkEmployee(){
				Employee emp=dao.getEmployeeById(123);
				assertEquals(emp,null);
			}
	
}
