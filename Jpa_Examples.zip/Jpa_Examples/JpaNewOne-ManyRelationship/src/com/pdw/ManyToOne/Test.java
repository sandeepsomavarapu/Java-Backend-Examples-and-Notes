package com.pdw.ManyToOne;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
   public static void main( String[ ] args ) {
   
   EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "many-one" );
   EntityManager entitymanager = emfactory.createEntityManager( );
   entitymanager.getTransaction( ).begin( );
   
   Department department = new Department();
   department.setDname("Development");
   department.setDloc("Hyderabad");
   //Store Department
   entitymanager.persist(department);

   Employee employee1 = new Employee("suresh", "banglore", 12000,department);
   
 //Store Employees
   entitymanager.persist(employee1);   
   //Create Department Entity
   

   entitymanager.getTransaction().commit();
   entitymanager.close();
   emfactory.close();
   }
}