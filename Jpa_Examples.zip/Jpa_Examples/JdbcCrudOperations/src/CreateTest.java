import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTest {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//loading the driver class
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//create the connection
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","capgemini","capgemini123");
		//create statement
		Statement statement=conn.createStatement();
		
		ResultSet result=statement.executeQuery("select * from emp123");//ddl,executeUpdate()..dml,executeQuery---DRL
		
		while(result.next())
		{
			System.out.println(result.getInt(1)+" "+result.getString(2));
		}
		conn.close();
	}
}
