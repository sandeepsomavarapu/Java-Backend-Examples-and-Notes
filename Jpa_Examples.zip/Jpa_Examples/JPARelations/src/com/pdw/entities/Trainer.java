package com.pdw.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Trainer implements Serializable {
	@Id
	@Column(length=10)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int trainerId;
	@Column(length=10)
	private String trainerName;
	@Column(length=10)
	private String city;
	@Column(length=10)
	private String state;
	@OneToOne(mappedBy="trainer")
	private Student  student;
	
	public int getTrainerId() {
		return trainerId;
	}
	public void setTrainerId(int trainerId) {
		this.trainerId = trainerId;
	}
	public String getTrainerName() {
		return trainerName;
	}
	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
	
	
	
}
