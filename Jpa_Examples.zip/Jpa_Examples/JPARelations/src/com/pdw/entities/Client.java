package com.pdw.entities;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
public class Client {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("1-1uni");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		Student student = new Student();
		student.setName("Deepak");
		student.setSmarks(100);

		Trainer trainer = new Trainer();
		trainer.setTrainerName("akash");
		trainer.setCity("HYD");
		trainer.setState("Telanagana");
		
		student.setTrainer(trainer);
		em.persist(student);
		em.getTransaction().commit();
		System.out.println("Added one student with address to database.");
		em.close();
		factory.close();
	}}