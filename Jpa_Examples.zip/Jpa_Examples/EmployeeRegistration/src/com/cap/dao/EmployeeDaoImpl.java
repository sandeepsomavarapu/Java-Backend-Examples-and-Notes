package com.cap.dao;

import javax.persistence.EntityManager;

import com.cap.entity.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	EntityManager entity = UtilJava.getEntityManager();
	@Override
	public int addEmployee(Employee emp) {
		entity.getTransaction().begin();
		entity.persist(emp);
		int empNum=emp.getEmpId();
		entity.getTransaction().commit();
		return empNum;
	}

	@Override
	public Employee getEmployee(int empId) {
		Employee emp=entity.find(Employee.class,empId);
		return emp;
	}

}
