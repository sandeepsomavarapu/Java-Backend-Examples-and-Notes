package com.cap.dao;

import com.cap.entity.Employee;

public interface EmployeeDao 
{

	int	addEmployee(Employee emp);
	
	Employee getEmployee(int empId);
	
}
