package com.cap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="EmpInfo")
public class Employee {
	@Column(name = "empId", length = 15)
	@Id
	private int empId;
	@Column(name = "empName", length = 15)
	private String empName;
	@Column(name = "empRole", length = 15)
	private String empRole;
	@Column(name = "address", length = 20)
	private String address;
	@Column(name = "empSal", length = 15)
	private int empSal;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpRole() {
		return empRole;
	}
	public void setEmpRole(String empRole) {
		this.empRole = empRole;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getEmpSal() {
		return empSal;
	}
	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "Employee Info \n empId=" + empId + ", empName=" + empName
				+ ", empRole=" + empRole + ", address=" + address + ", empSal="
				+ empSal+"\n";
	}
	public Employee(int empId,String empName, String empRole, String address,
			int empSal) {
		super();
		this.empId=empId;
		this.empName = empName;
		this.empRole = empRole;
		this.address = address;
		this.empSal = empSal;
	}
public Employee() {
	// TODO Auto-generated constructor stub
}	
}