package com.cap.service;

import com.cap.entity.Employee;

public interface EmployeeService 
{

	int	addEmployee(Employee emp);
	
	Employee getEmployee(int empId);
	
}
