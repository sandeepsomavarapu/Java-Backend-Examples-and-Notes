package com.cap.service;

import com.cap.dao.EmployeeDao;
import com.cap.dao.EmployeeDaoImpl;
import com.cap.entity.Employee;

public class EmployeeServiceImpl implements EmployeeService {
EmployeeDao dao=new EmployeeDaoImpl();
	@Override
	public int addEmployee(Employee emp) {
	int empId=dao.addEmployee(emp);
		return empId;
	}

	@Override
	public Employee getEmployee(int empId) {
	Employee employee=dao.getEmployee(empId);
		return employee;
	}

}
