package com.cap.client;

import java.util.Scanner;

import com.cap.entity.Employee;
import com.cap.service.EmployeeService;
import com.cap.service.EmployeeServiceImpl;

public class Client {
	static Employee emp = null;
	static EmployeeService service = new EmployeeServiceImpl();

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		while(true){
			System.out.println("Employee Registration");
			System.out.println("***********************");
			System.out.println("Choose One Option");
			System.out.println("1.Add Employee \n2.select Employee");
			int option = scanner.nextInt();
		switch (option) {
		case 1:
			System.out.println("Enter Your EmpNum");
			int empId = scanner.nextInt();
			System.out.println("Enter Your Name");
			String empName = scanner.next();
			System.out.println("Enter Your Role");
			String empRole = scanner.next();
			System.out.println("Enter Your Address");
			String empAdd = scanner.next();
			System.out.println("Enter Your Salary");
			int empSal = scanner.nextInt();
			emp = new Employee(empId,empName, empRole, empAdd, empSal);
			int empNum = service.addEmployee(emp);
			System.out.println("Registered successfully with EmpId :" + empNum);
			break;
		case 2:
			System.out.println("Enter EmpId");
			int empId1 = scanner.nextInt();
			Employee employee = service.getEmployee(empId1);
			System.out.println(employee);
			break;
		}
		}
	}
}
